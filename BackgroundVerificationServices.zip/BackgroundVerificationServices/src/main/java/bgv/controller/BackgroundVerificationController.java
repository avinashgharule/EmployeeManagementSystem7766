package bgv.controller;

import java.util.Random;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class BackgroundVerificationController {
	private static final String [] RESPONSES = {"good", "bad"};
	@GetMapping("/verify")
	public ResponseEntity<String> verifyBackground( ) {
		String response = RESPONSES [new Random().nextInt(RESPONSES.length)];
		return ResponseEntity.ok(response);
	}

}
