package com.jspiders.demo.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.jspiders.demo.entity.Employee;
import com.jspiders.demo.repository.EmpRepo;

@Service

public class EmpService {
	@Autowired
	private RestTemplate restTemplate;
	
	public void BackgroundVerification() {
		String url="http://localhost:8090/verify";
		ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null,String.class);
		String responseBody = response.getBody();
		System.out.println(responseBody);
	}
	
	@Autowired
	private EmpRepo repo;
	public void addEmp(Employee e) {
		
		repo.save(e);
	}
	
	public List<Employee>getAllEmp(){
		
		return repo.findAll();
	}
	
	public Employee getEmpById(int id) {
		Optional <Employee> e = repo.findById(id);
		if (e.isPresent()) {
			return e.get();
		}
		return null;
		
	}
	
	public void deleteEmp(int id) {
		
		repo.deleteById(id);
	
	}
	 public List<Employee> listAll(String keyword) {
	        if (keyword != null) {
	            return repo.search(keyword);
	        }
	        return repo.findAll();
	    }
	     
	    
	}

	


